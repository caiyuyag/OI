#include "testlib.h"

int main(int argc, char *argv[])
{
    // ��ʼ�� checker ���� ���� ���������в��������ļ�����
    registerTestlibCmd(argc, argv);

	int point = 0;
    double SAOCa = ans.readDouble();
    double SAOCo = ouf.readDouble();
    point += (SAOCa == SAOCo ? 3 : 0);
    
    double SACDa = ans.readDouble();
    double SACDo = ouf.readDouble();
    point += (SACDa == SACDo ? 3 : 0);
    
    double SAIDa = ans.readDouble();
    double SAIDo = ouf.readDouble();
    point += (SAIDa == SAIDo ? 3 : 0);
    
    double SAIODa = ans.readDouble();
    double SAIODo = ouf.readDouble();
    point += (SAIODa == SAIODo ? 4 : 0);

    if (point == 10)
        quitf(_ok, "The answer is correct.");
    else
        quitf(_pc(point), "The answer is wrong.");

    return 0;
}
